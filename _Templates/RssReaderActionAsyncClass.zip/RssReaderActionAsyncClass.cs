﻿using System.Threading.Tasks;

using DataLayer.Models;
using DbAccess.Core;

using LogicLayer._GenericActions;

namespace $rootnamespace$
{
    public class $safeitemname$ :
        ActionErrors,
        IActionAsync<Tin, Tout>
    {
        private IUnitOfWork _unitOfWork;

        public $safeitemname$(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public Task<Tout> ActionAsync(Tin userId)
        {
            return null;
        }
    }
}
