﻿using System.Collections.Generic;
using System.Collections.Immutable;
using System.ComponentModel.DataAnnotations;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        private IAction _action;

        public IImmutableList<ValidationResult> Errors => _action != null ? _action.Errors : null;

        public ResponseDto Method(RequestDto inData)
        {
            return null;
        }
    }
}
