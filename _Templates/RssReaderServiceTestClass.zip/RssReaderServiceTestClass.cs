﻿using System;
using System.Threading.Tasks;
using DataLayer.Code;
using DbAccess.Core;
using Moq;
using NUnit.Framework;
using Tests.Helpers;

namespace $rootnamespace$
{
    [TestFixture]
    class $safeitemname$
    {
        private DataContext _context;
        private UnitOfWork _unitOfWork;

        [SetUp]
        public void SetUp()
        {
            var options = InMemoryDb.CreateNewContextOptions();
            _context = new DataContext(options);
            _unitOfWork = new UnitOfWork(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _unitOfWork.Dispose();
        }

        [Test]
        public async Task Method_Scenario_Result()
        {
            //ARRANGE

            //ACT

            //ASSERT

        }
    }
}
